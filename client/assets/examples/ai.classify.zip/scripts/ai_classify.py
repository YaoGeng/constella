# -*- coding: utf-8 -*-
"""AI 规则判定（官方示例）：结构化判定自带路由；非法输出不臆测直接 miss。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    rule = str(ctx.params["rule"])
    prompt = (
        "按规则判定以下内容，输出 JSON {label: hit|miss, reason: ≤10字}。\n"
        f"规则：{rule}\n内容：{ctx.input}"
    )
    verdict = await ctx.llm.json(prompt, 0.1)
    label = str((verdict or {}).get("label", ""))
    reason = str((verdict or {}).get("reason", ""))[:10]
    if label == "hit":
        return {"branch": "hit", "label": label, "reason": reason}
    return {"branch": "miss", "reason": reason or "规则不符"}
