# -*- coding: utf-8 -*-
"""业务库读写（官方示例）：ctx.vault 统一收口，游标可续跑。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    op = str(ctx.params["op"])
    cursor_key = str(ctx.params.get("cursorKey", "") or "last_note_id")
    if op == "upsert 笔记":
        notes = (ctx.input or {}).get("notes", []) if isinstance(ctx.input, dict) else []
        await ctx.vault.upsertNotes(notes)
        ctx.log(f"落库 {len(notes)} 条笔记")
        return {"data": {"upserted": len(notes)}}
    result = await ctx.vault.exec(op, ctx.input, None)
    return {"data": {"op": op, "cursorKey": cursor_key, "result": result}}
