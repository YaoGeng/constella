// AI 话术生成（官方示例）：ctx.llm.fill 槽位填充＋反模板校验（最近已发不重复）。
import type { NodeCtx, NodeOut } from '@constella/sdk';

export async function run(ctx: NodeCtx): Promise<NodeOut> {
  const template = String(ctx.params.template);
  const tone = String(ctx.params.tone ?? '专业顾问');
  const recipients: Array<{ uid: string; nickname: string; noteTitle?: string }> =
    (ctx.input && typeof ctx.input === 'object' && Array.isArray((ctx.input as { queue?: unknown[] }).queue)
      ? (ctx.input as { queue: typeof recipients }).queue
      : []) as typeof recipients;
  const messages: Array<{ uid: string; text: string }> = [];
  for (const r of recipients) {
    const avoid = ctx.params.antiRepeat === '开' ? (await ctx.vault.recentSent(r.uid, 3)).join('｜') : undefined;
    const who = r.noteTitle !== undefined ? `${r.nickname}（分享过 ${r.noteTitle}）` : r.nickname;
    const text = await ctx.llm.fill(template, who, tone, avoid);
    ctx.log(`生成 ${r.nickname}：${text.slice(0, 24)}…`);
    messages.push({ uid: r.uid, text });
  }
  return { data: { messages } };
}
