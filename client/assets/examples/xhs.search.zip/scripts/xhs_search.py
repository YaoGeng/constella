# -*- coding: utf-8 -*-
"""搜索采集（滚动翻页）（官方示例）：多关键词逐个采集合并，去重内置。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    keywords = [k for k in str(ctx.params["keywords"]).splitlines() if k.strip()]
    limit = int(ctx.params.get("maxNotes", 40))
    sort = str(ctx.params.get("sort", "综合"))
    notes: list[object] = []
    seen: set[str] = set()
    for kw in keywords:
        ctx.log(f"采集关键词：{kw}（≤{limit} 条，{sort}）")
        cards = await ctx.browser.scrollCollect(kw, limit=limit, sort=sort)
        fresh = [c for c in cards if str((c or {}).get("url", "")) not in seen]
        for c in fresh:
            seen.add(str((c or {}).get("url", "")))
        notes.extend(fresh)
    return {"data": {"notes": notes, "keywordCount": len(keywords)}}
