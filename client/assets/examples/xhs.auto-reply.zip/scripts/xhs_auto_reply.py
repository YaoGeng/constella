# -*- coding: utf-8 -*-
"""即时回复一体机（官方示例·组合节点）：判向→意图→生成→发送登记；应对不了升级人工。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    persona = str(ctx.params["persona"])
    daily_limit = int(ctx.params.get("dailyLimit", 50))
    sessions = await ctx.im.pollUnread({"limit": 5, "cooldownMin": int(ctx.params.get("cooldownMin", 3))})
    replied: list[str] = []
    escalated: list[str] = []
    for s in sessions[:daily_limit]:
        sid = str((s or {}).get("id", ""))
        if not sid:
            continue
        text = await ctx.agent.reply(sid, persona)
        if text is None:
            escalated.append(sid)  # 应对不了——升级人工
            continue
        await ctx.im.send(sid, text)
        await ctx.vault.logChat({"uid": sid, "text": text, "echo": True})
        replied.append(sid)
    ctx.log(f"自动回复 {len(replied)} 条，升级 {len(escalated)} 条")
    if replied and not escalated:
        return {"branch": "replied", "replied": replied}
    if escalated:
        return {"branch": "escalated", "replied": replied, "escalated": escalated}
    return {"branch": "replied", "replied": replied}
