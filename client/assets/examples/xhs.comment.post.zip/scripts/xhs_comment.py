# -*- coding: utf-8 -*-
"""智能评论发布（官方示例）：逐笔记导航→截断至 maxLen→ctx.browser.comment 发布，频控（ratePerMin 条/分钟）内置。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    max_len = int(ctx.params.get("maxLen", 50))
    rate = int(ctx.params.get("ratePerMin", 4))
    items = (ctx.input or {}).get("data", []) if isinstance(ctx.input, dict) else []
    posted: list[object] = []
    for it in items:
        note = it if isinstance(it, dict) else {}
        url = str(note.get("url", ""))
        text = str(note.get("text", ""))[:max_len]
        if not url or not text:
            continue
        await ctx.browser.open(url)
        await ctx.browser.comment(text, rate)
        posted.append({"url": url, "len": len(text)})
        ctx.log(f"已评论 {url}（{len(posted)}/{len(items)}，频控 {rate} 条/分钟）")
    return {"data": {"posted": posted}}
