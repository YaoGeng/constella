# -*- coding: utf-8 -*-
"""登录/验证码闸（官方示例）：ctx.browser 探测登录态，双出口路由。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    home = str(ctx.params["homeUrl"])
    probe = str(ctx.params["probe"])
    await ctx.browser.open(home)
    if await ctx.browser.visible(probe):
        ctx.log("登录探针可见——判定未登录，走 blocked 交人工")
        return {"branch": "blocked", "homeUrl": home}
    ctx.log("登录探针不可见——判定已登录，放行 ok")
    return {"branch": "ok", "homeUrl": home}
