// 网页抓取（官方示例·ctx.net 面）：N1「网络」类目节点——经 main 网络代理 fetch，白名单外域名拒绝。
import type { NodeCtx, NodeOut } from '@constella/sdk';

export async function run(ctx: NodeCtx): Promise<NodeOut> {
  const headers: Record<string, string> = {};
  if (typeof ctx.params.token === 'string' && ctx.params.token !== '') {
    headers.authorization = `Bearer ${String(ctx.params.token)}`;
  }
  const res = await ctx.net.fetch(String(ctx.params.url), { headers });
  ctx.log(`抓取 ${String(ctx.params.url)} → ${res.status}`);
  const body = ctx.params.format === 'text' ? res.body : safeJson(res.body);
  return { data: { status: res.status, body } };
}

function safeJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
