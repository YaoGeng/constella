// 私信批量发送（官方示例）：ctx.im 收件轮询＋发送确认；频控（间隔/日上限）与熔断内置。
import type { NodeCtx, NodeOut } from '@constella/sdk';

export async function run(ctx: NodeCtx): Promise<NodeOut> {
  const minIntervalMs = Number(ctx.params.minInterval ?? 60) * 1000;
  const maxPerDay = Number(ctx.params.maxPerDay ?? 30);
  const confirmWait = Number(ctx.params.confirmWait ?? 8);
  const queue: Array<{ uid: string; text: string }> =
    (ctx.input && typeof ctx.input === 'object' && Array.isArray((ctx.input as { messages?: unknown[] }).messages)
      ? (ctx.input as { messages: typeof queue }).messages
      : []) as typeof queue;
  const sent: string[] = [];
  const deferred: string[] = [];
  let failures = 0;
  for (const m of queue.slice(0, maxPerDay)) {
    if (failures >= 3) { deferred.push(m.uid); continue; } // 连续 3 失败熔断——当行回队列交人工
    try {
      await ctx.im.send(m.uid, m.text);
      await ctx.sleep(confirmWait * 1000); // 发送确认轮询窗口
      await ctx.vault.logChat({ uid: m.uid, text: m.text, at: Date.now() });
      sent.push(m.uid);
      ctx.log(`已发送 ${m.uid}（${sent.length}/${maxPerDay}）`);
      failures = 0;
      await ctx.sleep(minIntervalMs + Math.floor(Math.random() * 120_000)); // 60–180s 随机间隔
    } catch {
      failures += 1;
      deferred.push(m.uid);
    }
  }
  return { data: { sent, deferred } };
}
