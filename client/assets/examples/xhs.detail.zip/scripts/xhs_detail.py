# -*- coding: utf-8 -*-
"""笔记详情+评论提取（官方示例）：逐笔记导航提取，评论按 user_id+content 去重。"""
from typing import Any

from constella_sdk import NodeCtx


async def run(ctx: NodeCtx) -> dict[str, Any]:
    items = (ctx.input or {}).get("notes", []) if isinstance(ctx.input, dict) else []
    fields = [f for f in str(ctx.params.get("fields", "title\ndesc")).splitlines() if f.strip()]
    with_comments = str(ctx.params.get("withComments", "是")) == "是"
    details: list[object] = []
    for it in items:
        url = str((it or {}).get("url", ""))
        if not url:
            continue
        note = await ctx.browser.extractNote(url, fields)
        if with_comments:
            note["comments"] = await ctx.browser.scrollComments(url)
        details.append(note)
        ctx.log(f"已提取 {url}（{len(note)} 字段）")
    return {"data": {"details": details}}
